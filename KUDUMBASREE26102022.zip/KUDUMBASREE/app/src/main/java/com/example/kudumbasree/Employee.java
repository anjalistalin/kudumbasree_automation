package com.example.kudumbasree;

public class Employee {
    String Kudumbasreename,Kid;

    public Employee() {
    }
}
