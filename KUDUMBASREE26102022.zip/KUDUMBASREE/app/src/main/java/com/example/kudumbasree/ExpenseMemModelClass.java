package com.example.kudumbasree;

public class ExpenseMemModelClass {
    String Kudumbasreeid,Reason,Amount,Date;

    public String getKudumbasreeid() {
        return Kudumbasreeid;
    }

    public String getReason() {
        return Reason;
    }

    public String getAmount() {
        return Amount;
    }

    public String getDate() {
        return Date;
    }
}
