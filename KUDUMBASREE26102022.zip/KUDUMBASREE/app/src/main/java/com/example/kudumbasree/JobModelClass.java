package com.example.kudumbasree;

public class JobModelClass {

    String Jobcategory,Venue,Interviewdate,Time;

    public String getJobcategory() {
        return Jobcategory;
    }

    public String getVenue() {
        return Venue;
    }

    public String getInterviewdate() {
        return Interviewdate;
    }

    public String getTime() {
        return Time;
    }
}
