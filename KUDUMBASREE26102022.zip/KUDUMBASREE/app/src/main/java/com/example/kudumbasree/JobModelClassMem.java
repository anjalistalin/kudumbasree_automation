package com.example.kudumbasree;

public class JobModelClassMem {
    String Jobcategory,Venue,Interviewdate,Time;

    public String getJobcategory() {
        return Jobcategory;
    }

    public void setJobcategory(String jobcategory) {
        Jobcategory = jobcategory;
    }

    public String getVenue() {
        return Venue;
    }

    public void setVenue(String venue) {
        Venue = venue;
    }

    public String getInterviewdate() {
        return Interviewdate;
    }

    public void setInterviewdate(String interviewdate) {
        Interviewdate = interviewdate;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }
}
