package com.example.kudumbasree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class JoinKudumbasree extends AppCompatActivity {

    Button Kjoin;
    ImageView kj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_kudumbasree);

        Kjoin=findViewById(R.id.join);
        kj=findViewById(R.id.jk);

        kj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 =new Intent(JoinKudumbasree.this,homescreenmember.class);
                startActivity(intent1);
            }
        });
        Kjoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(JoinKudumbasree.this,JoinRequest.class);
                startActivity(intent);
            }
        });
    }
}