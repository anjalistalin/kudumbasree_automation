package com.example.kudumbasree;

public class LoanPresident {

    String Loanname,Loanid,Category,Amount,Permonth,Period,Interest,Lastdatetoapply;

    public String getLoanname() {
        return Loanname;
    }

    public String getLoanid() {
        return Loanid;
    }

    public String getCategory() {
        return Category;
    }

    public String getAmount() {
        return Amount;
    }

    public String getPermonth() {
        return Permonth;
    }

    public String getPeriod() {
        return Period;
    }

    public String getInterest() {
        return Interest;
    }

    public String getLastdatetoapply() {
        return Lastdatetoapply;
    }
}
