package com.example.kudumbasree;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapterRequest extends RecyclerView.Adapter<MyAdapterRequest.MyViewholder> {
    RequestList context;
    ArrayList<REquestPresident> list;

    public MyAdapterRequest(RequestList context, ArrayList<REquestPresident> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.requsetitem, parent, false);
        return new MyAdapterRequest.MyViewholder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewholder holder, int position) {

        REquestPresident rEquestPresident=list.get(position);
        holder.Emailid.setText(rEquestPresident.getEmailid());
        holder.Name.setText(rEquestPresident.getName());
        holder.Phone.setText(rEquestPresident.getPhone());
        holder.Unitname.setText(rEquestPresident.getUnitname());
        holder.Unitid.setText(rEquestPresident.getUnitid());
        holder.DOB.setText(rEquestPresident.getDOB());


    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class MyViewholder extends RecyclerView.ViewHolder {
        TextView Emailid,Name,Phone,Unitname,Unitid,DOB;
        public MyViewholder(@NonNull View itemView) {
            super(itemView);
            Emailid=itemView.findViewById(R.id.email);
            Name=itemView.findViewById(R.id.namemem);
            Phone=itemView.findViewById(R.id.phoneno);
            Unitname=itemView.findViewById(R.id.unitname);
            Unitid=itemView.findViewById(R.id.kid);
            DOB=itemView.findViewById(R.id.dob);


        }
    }
}
