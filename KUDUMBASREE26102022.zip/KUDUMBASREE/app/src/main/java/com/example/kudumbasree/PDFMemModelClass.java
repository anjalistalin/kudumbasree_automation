package com.example.kudumbasree;

public class PDFMemModelClass {

    String name,url;

    public String getName() {
        return name;
    }

    public String getUrl() {
        return url;
    }

    public PDFMemModelClass() {


    }
}
