package com.example.kudumbasree;

import android.widget.TextView;

public class REquestPresident {
    String Emailid,Name,Phone,Unitname,Unitid,DOB;

    public String getEmailid() {
        return Emailid;
    }

    public String getName() {
        return Name;
    }

    public String getPhone() {
        return Phone;
    }

    public String getUnitname() {
        return Unitname;
    }

    public String getUnitid() {
        return Unitid;
    }

    public String getDOB() {
        return DOB;
    }
}
